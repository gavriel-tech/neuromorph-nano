# Owl survey, 3 October 2026

We walked the beech transect from the stile to the old quarry after dusk.
We counted seven tawny owls along the beech transect, two more than last year.
One barn owl was heard near the quarry but not seen.