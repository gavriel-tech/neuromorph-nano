The inner archive lists the spare parts.
